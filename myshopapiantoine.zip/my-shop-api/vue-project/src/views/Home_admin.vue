<template>
    <div class="button">
        <a href=# class="category">Product</a>
        <a href=# class="category">Categories</a>
        <a href=# class="category">Users</a>
    </div>
    <section class="menu">
        <p class="col">Product</p>
        <p class="col">Description</p>
        <p class="col">Price</p>
        <p class="col">ID</p>
        <p class="col">Category</p>
        <p class="col">Actions</p>
    </section>
    <article  v-for="product in getProducts.data['hydra:member']" :key="product.id" class="colonne">
        <!-- <article  v-for="product in getProducts.data" :key="product.id" class="colonne"> -->
    <section class="menu">
        <p class="col">{{product.name}}</p>
        <p class="col">{{ product.description }}</p>
        <p class="col">{{ product.price }}</p>
        <p class="col">{{product.id}}</p>
        <p class="col">{{product.categories}}</p>
        <button>EDIT</button>
        <button @click="delete_product(product.id)">DELETE</button>
    </section>
    </article>
</template>

<script>
import { useProducts } from '../stores/counter.js';
import { mapActions, mapState } from "pinia";


const token = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJpYXQiOjE3MDAxMjI3NDgsImV4cCI6MTcwMDEyNjM0OCwicm9sZXMiOlsiUk9MRV9BRE1JTiIsIlJPTEVfVVNFUiJdLCJ1c2VybmFtZSI6ImFudG9pbmUubG9wZXpAZXBpdGVjaC5kaWdpdGFsIn0.SmcGD9oKi4e4bqfV0e5RS3jrhmIYxYk5D1r04xuvtCoNvsKM3bFZuIUKQN9ieK8xslD_8nKw9uvwGY4toksrBmgVWe9eXyCD2xs-h9TAXptuOXnACPHtVqKi4_9caJiwqLtt1Vozyzw8R474pwjF88YR-VJr_KPGV8gHMzsCQ-u8k2tN8jxrVw8kGge-4foj7AIraHAtHcmr55KIZpvZXqNFvlXHSvqqhS4ApE1JokshX0r5qdHYSVok_B2DqIcf02Lc66AXxnXfFqWZVNKh5lG0uUWF2_jyqG77JBs9Qbu9IScxDpuR6gxOskyR9KsFPUnJULVuSif0A9lFMzZxUg';

export default {
    data() {
        return {
            products: []
        };
    },
    async mounted() {
        await this.fetchProduct;
    },
    computed: {
        ...mapActions(useProducts, ["fetchProduct"]),
        ...mapState(useProducts, ["getProducts"]),
    },
    methods: {
        headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
        },
            async delete_product(id) {
                try {
                    const response = await fetch(`http://localhost/api/products/${id}`, {
                        method: 'DELETE',
                        headers: {
                            'Authorization': `Bearer ${token}`,
                            'Content-Type': 'application/json',
                        },
                    });
                    if (!response.ok) {
                        throw new Error(`Request failed with status ${response.status}`);
                    }
                    location.reload();
                } catch (error) {
                    console.error('Error deleting product:', error.message);
                }
            },
        }
    }
</script>
<!-- FIN HTML -->


<!-- FIN JS -->

<style>

.button {
    padding-top: 100px;
    padding-left: 35%;
}
.category {
    padding: 50px
}
.menu {
    display: flex;
    padding-top: 40px;
}

.col {
    width: 200px;
    border: solid 1px black;
}
</style>

<!-- FIN CSS -->