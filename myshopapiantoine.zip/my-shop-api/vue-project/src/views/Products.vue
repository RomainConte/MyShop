<template>
  <section>
    <h1>Je suis sur la page Products</h1>
  </section>
</template>

<script></script>

<style></style>
